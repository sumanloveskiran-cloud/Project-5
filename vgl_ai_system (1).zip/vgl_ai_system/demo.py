"""
VGL Shop LC — Multi-Agent AI Demo
Run this to simulate a live show with 5 orders and see all agents in action.

Usage:
    python demo.py
"""

import os
import time
from dotenv import load_dotenv
from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from rich import box

load_dotenv()

from core.orchestrator import Orchestrator
from core.models import Order, StockItem

console = Console()

# ──────────────────────────────────────────────
# Sample data — tonight's Ruby Collection show
# ──────────────────────────────────────────────

STOCK = [
    StockItem(sku="RUB-001", product_name="Ruby Sterling Silver Ring",   category="ring",     units_remaining=6,  units_sold_today=44, price=1899, margin_pct=42),
    StockItem(sku="RUB-002", product_name="Ruby Heart Pendant Necklace", category="pendant",  units_remaining=17, units_sold_today=33, price=2299, margin_pct=51),
    StockItem(sku="RUB-003", product_name="Ruby & Diamond Earrings",     category="earring",  units_remaining=29, units_sold_today=21, price=2799, margin_pct=55),
    StockItem(sku="RUB-004", product_name="Mozambique Ruby Bracelet",    category="bracelet", units_remaining=4,  units_sold_today=46, price=3499, margin_pct=48),
    StockItem(sku="RUB-005", product_name="Ruby Solitaire Gold Ring",    category="ring",     units_remaining=36, units_sold_today=14, price=4199, margin_pct=62),
]

ORDERS = [
    Order(order_id="#84201", customer_id="C001", customer_name="Priya Mehta",
          customer_phone="+919876543210", sku="RUB-001",
          product_name="Ruby Sterling Silver Ring", category="ring",
          price=1899, size="5", order_hour=23, is_first_order=True, customer_return_rate=0.0),

    Order(order_id="#84202", customer_id="C002", customer_name="Dorothy Sharma",
          customer_phone="+919876543211", sku="RUB-003",
          product_name="Ruby & Diamond Earrings", category="earring",
          price=2799, order_hour=20, is_first_order=False, customer_return_rate=0.08),

    Order(order_id="#84203", customer_id="C003", customer_name="Sunita Rajan",
          customer_phone="+919876543212", sku="RUB-002",
          product_name="Ruby Heart Pendant Necklace", category="pendant",
          price=2299, order_hour=22, is_first_order=True, customer_return_rate=0.0),

    Order(order_id="#84204", customer_id="C004", customer_name="Meena Gupta",
          customer_phone="+919876543213", sku="RUB-005",
          product_name="Ruby Solitaire Gold Ring", category="ring",
          price=4199, size="7", order_hour=19, is_first_order=False, customer_return_rate=0.05),

    Order(order_id="#84205", customer_id="C005", customer_name="Kavita Pillai",
          customer_phone="+919876543214", sku="RUB-004",
          product_name="Mozambique Ruby Bracelet", category="bracelet",
          price=3499, order_hour=21, is_first_order=True, customer_return_rate=0.0),
]


def print_summary_table(results: list[dict]):
    table = Table(title="Tonight's Order Risk Summary", box=box.ROUNDED)
    table.add_column("Order",    style="dim",    width=8)
    table.add_column("Customer", width=14)
    table.add_column("Product",  width=26)
    table.add_column("Risk",     width=6)
    table.add_column("Level",    width=8)
    table.add_column("Action",   width=10)

    colors = {"low": "green", "medium": "yellow", "high": "red"}
    for r in results:
        risk = r["return_risk"]
        level = risk["risk_level"]
        table.add_row(
            r["order_id"],
            risk.get("customer_name", ""),
            ORDERS[results.index(r)].product_name[:25],
            f"{risk['risk_score']}/100",
            f"[{colors[level]}]{level}[/{colors[level]}]",
            risk["action"],
        )
    console.print(table)


def main():
    console.print(Panel.fit(
        "[bold white]VGL Shop LC — Multi-Agent AI System[/bold white]\n"
        "[dim]Inventory Management + Return Prediction Demo[/dim]",
        border_style="blue"
    ))

    if not os.getenv("ANTHROPIC_API_KEY"):
        console.print("[red]Error: ANTHROPIC_API_KEY not set in .env[/red]")
        console.print("Copy .env.example → .env and add your key.")
        return

    orchestrator = Orchestrator()
    results = []

    # ── Process each order ──────────────────────────────────
    console.print(f"\n[bold]Processing {len(ORDERS)} orders from tonight's Ruby Collection show...[/bold]\n")

    for i, order in enumerate(ORDERS):
        console.rule(f"Order {i+1}/{len(ORDERS)}")
        result = orchestrator.handle_new_order(order, STOCK)
        result["order_id"] = order.order_id
        result["return_risk"]["customer_name"] = order.customer_name
        results.append(result)

        if i < len(ORDERS) - 1:
            console.print("[dim]Waiting 1s before next order...[/dim]")
            time.sleep(1)

    # ── Summary table ────────────────────────────────────────
    console.print()
    print_summary_table(results)

    # ── Daily report ─────────────────────────────────────────
    console.rule("End-of-Day Report")
    report = orchestrator.generate_daily_report(total_orders=len(ORDERS))

    console.print(Panel(
        "\n".join([
            f"[bold]Date:[/bold] {report['date']}",
            f"[bold]Total orders:[/bold] {report['total_orders']}",
            f"[bold]Predicted returns:[/bold] {report['predicted_returns']}",
            f"[bold]Estimated cost saved:[/bold] ₹{report['estimated_return_cost_saved']:,.0f}",
        ]),
        title="Daily Metrics", border_style="green"
    ))

    console.print("\n[bold yellow]Top patterns:[/bold yellow]")
    for p in report["top_patterns"]:
        console.print(f"  • {p}")

    console.print("\n[bold green]Recommendations:[/bold green]")
    for r in report["recommendations"]:
        console.print(f"  → {r}")

    console.print("\n[bold]Demo complete.[/bold] In production, connect wynk.shoplc.io order webhooks to POST /order/new")


if __name__ == "__main__":
    main()
