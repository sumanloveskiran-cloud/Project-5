# VGL Shop LC — Multi-Agent AI System

AI-powered **Inventory Management** and **Return Prediction** for Shop LC live TV shopping shows.

## Architecture

```
New Order / Stock Event
        │
        ▼
  Orchestrator  ──── routes tasks ────►  Return Predictor Agent
        │                               Inventory Monitor Agent
        │                                       │
        ▼                                       ▼
 Intervention Agent                       Dashboard update
 (IVR call / SMS)
        │
        ▼
   IVR Queue / Call Center
```

## Agents

| Agent | Role |
|---|---|
| **Orchestrator** | Receives events, routes to agents in parallel |
| **Return Predictor** | Scores each order 0–100 for return probability |
| **Inventory Monitor** | Watches live stock, advises host team in real time |
| **Intervention Agent** | Generates IVR scripts, triggers outreach for high-risk orders |
| **Insight Agent** | End-of-day pattern analysis and recommendations |

## Setup

```bash
# 1. Clone / unzip the project
cd vgl_ai_system

# 2. Install dependencies
pip install -r requirements.txt

# 3. Set your API key
cp .env.example .env
# Edit .env and add your ANTHROPIC_API_KEY

# 4. Run the demo
python demo.py

# 5. Start the API server
uvicorn api.server:app --reload --port 8000

# 6. Run tests
pytest tests/ -v
```

## API Endpoints

| Method | Endpoint | Description |
|---|---|---|
| `POST` | `/order/new` | Process a new order through all agents |
| `POST` | `/inventory/update` | Update host advice when stock changes |
| `POST` | `/report/daily` | Generate end-of-day insight report |
| `GET`  | `/health` | Check system status |

### Example: New Order

```bash
curl -X POST http://localhost:8000/order/new \
  -H "Content-Type: application/json" \
  -d '{
    "order": {
      "order_id": "#84201",
      "customer_id": "C001",
      "customer_name": "Priya Mehta",
      "customer_phone": "+919876543210",
      "sku": "RUB-001",
      "product_name": "Ruby Sterling Silver Ring",
      "category": "ring",
      "price": 1899,
      "size": "5",
      "order_hour": 23,
      "is_first_order": true,
      "customer_return_rate": 0.0
    },
    "current_stock": [
      {"sku":"RUB-001","product_name":"Ruby Sterling Silver Ring","category":"ring","units_remaining":6,"units_sold_today":44,"price":1899,"margin_pct":42}
    ]
  }'
```

## Connecting to Wynk (wynk.shoplc.io)

```python
from api.wynk_client import WynkClient

client = WynkClient()

# Register webhook — Wynk will POST new orders to your server automatically
client.register_order_webhook("https://your-server.com/order/new")

# Fetch live inventory
stock = client.get_live_stock(show_id="tonight")

# Fetch customer return rate
rate = client.get_customer_return_rate("C001")
```

## Production Deployment

```
1. Deploy API server on AWS/GCP/Azure (or Railway/Render for quick demo)
2. Register Wynk webhook → /order/new
3. Connect IVR_WEBHOOK_URL in .env to your telephony provider (Exotel / Ozonetel / Twilio)
4. Schedule /report/daily via cron at midnight
5. Point dashboard UI to the API
```

## Tech Stack

- **Python 3.11+**
- **Anthropic Claude API** (`claude-sonnet-4-6`) — agent intelligence
- **FastAPI** — REST API server
- **Pydantic** — data validation and models
- **concurrent.futures** — parallel agent execution
- **Rich** — beautiful terminal output for demo

## Business Impact

| Metric | Target |
|---|---|
| Return rate reduction | 4–6% |
| Cost saved per prevented return | ₹350 |
| IVR intervention success rate | ~60% |
| Stock-out incidents prevented | Real-time |
