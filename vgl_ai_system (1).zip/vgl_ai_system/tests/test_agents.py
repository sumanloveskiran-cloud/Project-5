"""
Unit tests for VGL Shop LC AI agents.
Run with:  pytest tests/test_agents.py -v
"""

import pytest
from unittest.mock import patch, MagicMock
from core.models import Order, StockItem, RiskLevel, InterventionAction


# ── Fixtures ───────────────────────────────────────────────────────────────

@pytest.fixture
def sample_order_high_risk():
    return Order(
        order_id="#TEST-001",
        customer_id="C001",
        customer_name="Priya Mehta",
        customer_phone="+919876543210",
        sku="RUB-001",
        product_name="Ruby Sterling Silver Ring",
        category="ring",
        price=1899,
        size="5",
        order_hour=23,
        is_first_order=True,
        customer_return_rate=0.0,
    )


@pytest.fixture
def sample_order_low_risk():
    return Order(
        order_id="#TEST-002",
        customer_id="C002",
        customer_name="Meena Gupta",
        customer_phone="+919876543211",
        sku="RUB-003",
        product_name="Ruby Diamond Earrings",
        category="earring",
        price=2799,
        order_hour=18,
        is_first_order=False,
        customer_return_rate=0.05,
    )


@pytest.fixture
def sample_stock():
    return [
        StockItem(sku="RUB-001", product_name="Ruby Ring",     category="ring",    units_remaining=6,  units_sold_today=44, price=1899, margin_pct=42),
        StockItem(sku="RUB-003", product_name="Ruby Earrings", category="earring", units_remaining=29, units_sold_today=21, price=2799, margin_pct=55),
        StockItem(sku="RUB-005", product_name="Gold Ring",     category="ring",    units_remaining=36, units_sold_today=14, price=4199, margin_pct=62),
    ]


# ── Return Predictor ───────────────────────────────────────────────────────

class TestReturnPredictorAgent:

    def test_high_risk_order(self, sample_order_high_risk):
        """First-time buyer + size 5 ring + late night → high risk."""
        from agents.return_predictor import ReturnPredictorAgent
        agent = ReturnPredictorAgent()

        mock_response = '{"risk_score": 75, "risk_level": "high", "reasons": ["first-time buyer", "size 5 ring", "ordered at 11 PM"], "action": "ivr_call"}'
        with patch.object(agent, 'call_llm', return_value=mock_response):
            result = agent.score(sample_order_high_risk)

        assert result.risk_score >= 66
        assert result.risk_level == RiskLevel.HIGH
        assert result.action == InterventionAction.IVR_CALL
        assert result.order_id == "#TEST-001"

    def test_low_risk_order(self, sample_order_low_risk):
        """Repeat buyer, earring, daytime → low risk."""
        from agents.return_predictor import ReturnPredictorAgent
        agent = ReturnPredictorAgent()

        mock_response = '{"risk_score": 12, "risk_level": "low", "reasons": ["repeat buyer"], "action": "none"}'
        with patch.object(agent, 'call_llm', return_value=mock_response):
            result = agent.score(sample_order_low_risk)

        assert result.risk_score <= 30
        assert result.risk_level == RiskLevel.LOW
        assert result.action == InterventionAction.NONE


# ── Inventory Monitor ──────────────────────────────────────────────────────

class TestInventoryMonitorAgent:

    def test_advise_recommends_high_margin_sku(self, sample_stock):
        from agents.inventory_monitor import InventoryMonitorAgent
        agent = InventoryMonitorAgent()

        mock_response = '''{
            "push_next_sku": "RUB-005",
            "avoid_skus": ["RUB-001"],
            "alerts": [{"sku": "RUB-001", "alert_type": "critical", "units_remaining": 6, "recommendation": "Only 6 units left"}],
            "host_tip": "Feature Gold Ring next — highest margin and 36 units available."
        }'''
        with patch.object(agent, 'call_llm', return_value=mock_response):
            result = agent.advise(sample_stock)

        assert result.push_next.sku == "RUB-005"
        assert "RUB-001" in result.avoid_now
        assert len(result.alerts) == 1
        assert result.alerts[0].alert_type == "critical"

    def test_alert_generated_for_critical_stock(self, sample_stock):
        from agents.inventory_monitor import InventoryMonitorAgent
        agent = InventoryMonitorAgent()

        mock_response = '''{
            "push_next_sku": "RUB-005",
            "avoid_skus": ["RUB-001"],
            "alerts": [{"sku": "RUB-001", "alert_type": "critical", "units_remaining": 6, "recommendation": "Stop featuring"}],
            "host_tip": "Move to Gold Ring."
        }'''
        with patch.object(agent, 'call_llm', return_value=mock_response):
            result = agent.advise(sample_stock)

        critical_alerts = [a for a in result.alerts if a.alert_type == "critical"]
        assert len(critical_alerts) >= 1


# ── Intervention Agent ─────────────────────────────────────────────────────

class TestInterventionAgent:

    def test_script_generated(self, sample_order_high_risk):
        from agents.intervention_agent import InterventionAgent
        from agents.return_predictor import ReturnPredictorAgent
        from core.models import ReturnRiskResult, RiskLevel, InterventionAction

        agent = InterventionAgent()
        risk = ReturnRiskResult(
            order_id="#TEST-001",
            risk_score=75,
            risk_level=RiskLevel.HIGH,
            reasons=["first-time buyer", "size 5 ring"],
            action=InterventionAction.IVR_CALL,
        )
        mock_script = "Namaste Priya ji! Aapka Ruby Ring ka order mil gaya. Size 5 sahi hai? Koi sawaal ho toh hum madad karenge!"
        with patch.object(agent, 'call_llm', return_value=mock_script):
            result = agent.trigger(sample_order_high_risk, risk)

        assert result["status"] in ("simulated_ivr", "queued")
        assert "script" in result
        assert len(result["script"]) > 0

    def test_no_intervention_for_low_risk(self, sample_order_low_risk):
        from agents.intervention_agent import InterventionAgent
        from core.models import ReturnRiskResult, RiskLevel, InterventionAction

        agent = InterventionAgent()
        risk = ReturnRiskResult(
            order_id="#TEST-002",
            risk_score=12,
            risk_level=RiskLevel.LOW,
            reasons=["repeat buyer"],
            action=InterventionAction.NONE,
        )
        result = agent.trigger(sample_order_low_risk, risk)
        assert result["status"] == "no_action"


# ── Orchestrator ───────────────────────────────────────────────────────────

class TestOrchestrator:

    def test_handle_new_order_returns_full_result(self, sample_order_high_risk, sample_stock):
        from core.orchestrator import Orchestrator
        from agents.return_predictor import ReturnPredictorAgent
        from agents.inventory_monitor import InventoryMonitorAgent
        from agents.intervention_agent import InterventionAgent
        from core.models import ReturnRiskResult, InventoryAdvice, RiskLevel, InterventionAction

        orch = Orchestrator()

        mock_risk = ReturnRiskResult(
            order_id="#TEST-001", risk_score=75,
            risk_level=RiskLevel.HIGH, reasons=["first-time buyer"],
            action=InterventionAction.IVR_CALL
        )
        mock_inv = InventoryAdvice(
            push_next=sample_stock[2],
            avoid_now=["RUB-001"],
            alerts=[],
            host_tip="Feature Gold Ring next."
        )

        with patch.object(orch.return_predictor, 'score', return_value=mock_risk), \
             patch.object(orch.inventory_monitor, 'advise', return_value=mock_inv), \
             patch.object(orch.intervention_agent, 'trigger', return_value={"status": "simulated_ivr"}):

            result = orch.handle_new_order(sample_order_high_risk, sample_stock)

        assert "return_risk" in result
        assert "inventory_advice" in result
        assert result["return_risk"]["risk_score"] == 75
        assert result["inventory_advice"]["host_tip"] == "Feature Gold Ring next."
