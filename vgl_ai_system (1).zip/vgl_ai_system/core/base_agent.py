import anthropic
import json
import os
from rich.console import Console

console = Console()
client = anthropic.Anthropic(api_key=os.getenv("ANTHROPIC_API_KEY"))
MODEL = "claude-sonnet-4-6"


class BaseAgent:
    """All specialist agents inherit from this."""

    name: str = "base"
    system_prompt: str = ""

    def call_llm(self, user_message: str, max_tokens: int = 500) -> str:
        """Send a message to Claude and return the text response."""
        console.log(f"[dim][{self.name}] calling LLM...[/dim]")
        response = client.messages.create(
            model=MODEL,
            max_tokens=max_tokens,
            system=self.system_prompt,
            messages=[{"role": "user", "content": user_message}],
        )
        return response.content[0].text

    def call_llm_json(self, user_message: str, max_tokens: int = 500) -> dict:
        """Call Claude and parse the response as JSON."""
        raw = self.call_llm(user_message, max_tokens)
        # Strip markdown code fences if present
        clean = raw.strip().removeprefix("```json").removeprefix("```").removesuffix("```").strip()
        return json.loads(clean)
