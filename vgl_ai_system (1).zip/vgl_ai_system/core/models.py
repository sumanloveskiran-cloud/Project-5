from pydantic import BaseModel
from typing import Optional
from enum import Enum


class RiskLevel(str, Enum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"


class InterventionAction(str, Enum):
    NONE = "none"
    IVR_CALL = "ivr_call"
    SMS = "sms"


class Customer(BaseModel):
    customer_id: str
    name: str
    phone: str
    total_orders: int = 0
    total_returns: int = 0
    preferred_categories: list[str] = []


class Order(BaseModel):
    order_id: str
    customer_id: str
    customer_name: str
    customer_phone: str
    sku: str
    product_name: str
    category: str
    price: float
    size: Optional[str] = None
    order_hour: int          # 0-23
    is_first_order: bool = False
    customer_return_rate: float = 0.0  # historical return rate


class StockItem(BaseModel):
    sku: str
    product_name: str
    category: str
    units_remaining: int
    units_sold_today: int
    price: float
    margin_pct: float


class ReturnRiskResult(BaseModel):
    order_id: str
    risk_score: int              # 0-100
    risk_level: RiskLevel
    reasons: list[str]
    action: InterventionAction
    ivr_script: Optional[str] = None


class InventoryAlert(BaseModel):
    sku: str
    product_name: str
    units_remaining: int
    alert_type: str              # "critical", "low", "stockout_imminent"
    recommendation: str


class InventoryAdvice(BaseModel):
    push_next: StockItem
    avoid_now: list[str]         # SKUs to not feature
    alerts: list[InventoryAlert]
    host_tip: str


class DailyInsight(BaseModel):
    date: str
    total_orders: int
    predicted_returns: int
    estimated_return_cost_saved: float
    top_patterns: list[str]
    recommendations: list[str]
