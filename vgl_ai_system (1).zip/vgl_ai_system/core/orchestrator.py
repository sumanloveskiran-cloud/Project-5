import concurrent.futures
from rich.console import Console
from rich.panel import Panel

from core.models import Order, StockItem, ReturnRiskResult, InventoryAdvice
from agents.return_predictor import ReturnPredictorAgent
from agents.inventory_monitor import InventoryMonitorAgent
from agents.intervention_agent import InterventionAgent
from agents.insight_agent import InsightAgent

console = Console()


class Orchestrator:
    """
    Central coordinator for all VGL Shop LC AI agents.

    Flow for a new order:
    ┌─────────────┐
    │  New Order  │
    └──────┬──────┘
           │  (parallel)
    ┌──────┴──────────────────┐
    │                         │
    ▼                         ▼
    Return Predictor    Inventory Monitor
    │                         │
    └──────────┬──────────────┘
               │
               ▼
        Intervention Agent  (if risk ≥ medium)
               │
               ▼
          IVR / SMS queue
    """

    def __init__(self):
        self.return_predictor = ReturnPredictorAgent()
        self.inventory_monitor = InventoryMonitorAgent()
        self.intervention_agent = InterventionAgent()
        self.insight_agent = InsightAgent()

        # In-memory store for the day's results (replace with DB in production)
        self._risk_log: list[ReturnRiskResult] = []

    # ─────────────────────────────────────────────
    # Public: handle a new incoming order
    # ─────────────────────────────────────────────

    def handle_new_order(self, order: Order, stock: list[StockItem]) -> dict:
        console.print(Panel(
            f"[bold]New order[/bold] {order.order_id} — {order.product_name} — {order.customer_name}",
            style="blue"
        ))

        # Run return scoring + inventory check in parallel
        with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
            risk_future = pool.submit(self.return_predictor.score, order)
            inv_future  = pool.submit(self.inventory_monitor.advise, stock)

        risk: ReturnRiskResult = risk_future.result()
        inv:  InventoryAdvice  = inv_future.result()

        self._risk_log.append(risk)

        console.print(f"  [yellow]Return risk:[/yellow] {risk.risk_score}/100 ({risk.risk_level}) — {', '.join(risk.reasons)}")
        console.print(f"  [green]Host tip:[/green] {inv.host_tip}")

        # Trigger intervention if needed
        intervention_result = None
        if risk.action.value != "none":
            console.print(f"  [red]Triggering {risk.action.value} for {order.customer_name}[/red]")
            intervention_result = self.intervention_agent.trigger(order, risk)
            console.print(f"  [dim]Intervention: {intervention_result['status']}[/dim]")

        return {
            "order_id": order.order_id,
            "return_risk": risk.model_dump(),
            "inventory_advice": inv.model_dump(),
            "intervention": intervention_result,
        }

    # ─────────────────────────────────────────────
    # Public: handle a stock update during the show
    # ─────────────────────────────────────────────

    def handle_stock_update(self, stock: list[StockItem]) -> InventoryAdvice:
        console.print("[blue]Stock update received — re-evaluating show inventory...[/blue]")
        return self.inventory_monitor.advise(stock)

    # ─────────────────────────────────────────────
    # Public: end-of-day insights
    # ─────────────────────────────────────────────

    def generate_daily_report(self, total_orders: int) -> dict:
        console.print(Panel("Generating end-of-day insight report...", style="purple"))
        insight = self.insight_agent.generate(self._risk_log, total_orders)
        self._risk_log.clear()   # reset for next day
        return insight.model_dump()
