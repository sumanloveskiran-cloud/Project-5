"""
Wynk API Client — wynk.shoplc.io

In production: replace mock methods with real HTTP calls to the Wynk API.
All methods return the same types so the agents never change.
"""

import httpx
import os
from core.models import StockItem, Order, Customer


class WynkClient:

    def __init__(self):
        self.base_url = os.getenv("WYNK_API_URL", "https://wynk.shoplc.io/api")
        self.api_key  = os.getenv("WYNK_API_KEY", "")
        self.headers  = {"Authorization": f"Bearer {self.api_key}"}

    # ── Inventory ──────────────────────────────────────────

    def get_live_stock(self, show_id: str = "tonight") -> list[StockItem]:
        """Fetch all SKUs in the current live show with their stock levels."""
        if not self.api_key:
            return self._mock_stock()
        try:
            r = httpx.get(f"{self.base_url}/shows/{show_id}/inventory",
                          headers=self.headers, timeout=5)
            r.raise_for_status()
            return [StockItem(**item) for item in r.json()["items"]]
        except Exception:
            return self._mock_stock()

    def get_stock_item(self, sku: str) -> StockItem | None:
        """Fetch a single SKU."""
        for item in self.get_live_stock():
            if item.sku == sku:
                return item
        return None

    # ── Orders ─────────────────────────────────────────────

    def get_order(self, order_id: str) -> Order | None:
        """Fetch order details by ID."""
        if not self.api_key:
            return None
        try:
            r = httpx.get(f"{self.base_url}/orders/{order_id}",
                          headers=self.headers, timeout=5)
            r.raise_for_status()
            return Order(**r.json())
        except Exception:
            return None

    # ── Customer ───────────────────────────────────────────

    def get_customer(self, customer_id: str) -> Customer | None:
        """Fetch customer profile and history."""
        if not self.api_key:
            return self._mock_customer(customer_id)
        try:
            r = httpx.get(f"{self.base_url}/customers/{customer_id}",
                          headers=self.headers, timeout=5)
            r.raise_for_status()
            return Customer(**r.json())
        except Exception:
            return None

    def get_customer_return_rate(self, customer_id: str) -> float:
        """Return historical return rate 0.0–1.0 for a customer."""
        c = self.get_customer(customer_id)
        if not c or c.total_orders == 0:
            return 0.0
        return round(c.total_returns / c.total_orders, 3)

    # ── Webhooks (register with Wynk so orders auto-trigger agents) ────────

    def register_order_webhook(self, target_url: str) -> dict:
        """
        Tell Wynk to POST every new order to our /order/new endpoint.
        Call this once during deployment setup.
        """
        if not self.api_key:
            return {"status": "simulated", "webhook_url": target_url}
        try:
            r = httpx.post(f"{self.base_url}/webhooks",
                           headers=self.headers,
                           json={"event": "order.created", "url": target_url},
                           timeout=5)
            r.raise_for_status()
            return r.json()
        except Exception as e:
            return {"status": "error", "detail": str(e)}

    # ── Mock data (used when no API key is set) ────────────

    def _mock_stock(self) -> list[StockItem]:
        return [
            StockItem(sku="RUB-001", product_name="Ruby Sterling Silver Ring",
                      category="ring",     units_remaining=6,  units_sold_today=44,
                      price=1899, margin_pct=42),
            StockItem(sku="RUB-002", product_name="Ruby Heart Pendant Necklace",
                      category="pendant",  units_remaining=17, units_sold_today=33,
                      price=2299, margin_pct=51),
            StockItem(sku="RUB-003", product_name="Ruby & Diamond Earrings",
                      category="earring",  units_remaining=29, units_sold_today=21,
                      price=2799, margin_pct=55),
            StockItem(sku="RUB-004", product_name="Mozambique Ruby Bracelet",
                      category="bracelet", units_remaining=4,  units_sold_today=46,
                      price=3499, margin_pct=48),
            StockItem(sku="RUB-005", product_name="Ruby Solitaire Gold Ring",
                      category="ring",     units_remaining=36, units_sold_today=14,
                      price=4199, margin_pct=62),
        ]

    def _mock_customer(self, customer_id: str) -> Customer:
        return Customer(
            customer_id=customer_id,
            name="Sample Customer",
            phone="+919999999999",
            total_orders=3,
            total_returns=0,
            preferred_categories=["ring", "pendant"],
        )
