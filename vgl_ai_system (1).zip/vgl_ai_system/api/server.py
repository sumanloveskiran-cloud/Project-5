from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from core.orchestrator import Orchestrator
from core.models import Order, StockItem
from dotenv import load_dotenv

load_dotenv()

app = FastAPI(
    title="VGL Shop LC — AI Agent System",
    description="Multi-agent AI for inventory management and return prediction",
    version="1.0.0",
)

orchestrator = Orchestrator()


# ──────────────────────────────────────────────────────────
# Request bodies
# ──────────────────────────────────────────────────────────

class NewOrderRequest(BaseModel):
    order: Order
    current_stock: list[StockItem]


class StockUpdateRequest(BaseModel):
    stock: list[StockItem]


class DailyReportRequest(BaseModel):
    total_orders: int


# ──────────────────────────────────────────────────────────
# Endpoints
# ──────────────────────────────────────────────────────────

@app.get("/health")
def health():
    return {"status": "ok", "agents": ["return_predictor", "inventory_monitor", "intervention_agent", "insight_agent"]}


@app.post("/order/new")
def new_order(request: NewOrderRequest):
    """
    Called when a new order is placed.
    Runs return prediction + inventory check in parallel.
    Triggers IVR/SMS intervention if risk is high.
    """
    try:
        return orchestrator.handle_new_order(request.order, request.current_stock)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/inventory/update")
def stock_update(request: StockUpdateRequest):
    """
    Called when stock levels change during the live show.
    Returns updated host advice.
    """
    try:
        advice = orchestrator.handle_stock_update(request.stock)
        return advice.model_dump()
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/report/daily")
def daily_report(request: DailyReportRequest):
    """
    Called at end of day (e.g. via cron at midnight).
    Returns patterns and recommendations for ops team.
    """
    try:
        return orchestrator.generate_daily_report(request.total_orders)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
