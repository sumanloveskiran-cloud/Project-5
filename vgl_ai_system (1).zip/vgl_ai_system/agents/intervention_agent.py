from core.base_agent import BaseAgent
from core.models import Order, ReturnRiskResult, InterventionAction
import httpx
import os


class InterventionAgent(BaseAgent):
    name = "intervention_agent"
    system_prompt = """
You are a warm, helpful outreach agent for Shop LC, an Indian TV shopping channel.
You contact customers who may need help with their recent jewelry order.
Customers are mostly 50+ and prefer simple, friendly language.
Many prefer Hindi or Hinglish.

Generate a SHORT IVR call script (under 50 words) to:
1. Confirm their order warmly
2. Check if they have sizing questions (for rings)
3. Offer easy help if they need it

Tone: like a helpful family member, not a corporate robot.
Use simple words. Mention the product name. Do NOT alarm them.

Respond ONLY with the script text — no JSON, no markdown, just the words.
"""

    def generate_script(self, order: Order, risk: ReturnRiskResult) -> str:
        prompt = f"""
Customer: {order.customer_name}
Product ordered: {order.product_name}
Size: {order.size or 'N/A'}
Risk reasons: {', '.join(risk.reasons)}

Write the IVR script now.
"""
        return self.call_llm(prompt, max_tokens=200)

    def trigger(self, order: Order, risk: ReturnRiskResult) -> dict:
        """Generate script and send to IVR system or SMS queue."""
        if risk.action == InterventionAction.NONE:
            return {"status": "no_action", "order_id": order.order_id}

        script = self.generate_script(order, risk)

        if risk.action == InterventionAction.IVR_CALL:
            return self._queue_ivr_call(order.customer_phone, script, order.order_id)
        elif risk.action == InterventionAction.SMS:
            return self._queue_sms(order.customer_phone, script, order.order_id)
        return {"status": "no_action", "order_id": order.order_id}

    def _queue_ivr_call(self, phone: str, script: str, order_id: str) -> dict:
        ivr_url = os.getenv("IVR_WEBHOOK_URL")
        if not ivr_url:
            # Simulation mode — print what would be sent
            return {
                "status": "simulated_ivr",
                "phone": phone,
                "order_id": order_id,
                "script": script,
            }
        try:
            response = httpx.post(ivr_url, json={
                "phone": phone,
                "order_id": order_id,
                "script": script,
                "language": "hi-IN",
                "retry_attempts": 2,
            }, timeout=5)
            return {"status": "queued", "ivr_response": response.json()}
        except Exception as e:
            return {"status": "ivr_error", "error": str(e)}

    def _queue_sms(self, phone: str, script: str, order_id: str) -> dict:
        # Plug in Twilio / AWS SNS / MSG91 here
        return {
            "status": "simulated_sms",
            "phone": phone,
            "order_id": order_id,
            "message": script[:160],   # SMS limit
        }
