from core.base_agent import BaseAgent
from core.models import StockItem, InventoryAdvice, InventoryAlert
import json


class InventoryMonitorAgent(BaseAgent):
    name = "inventory_monitor"
    system_prompt = """
You are a live show inventory advisor for Shop LC, an Indian TV home shopping channel.
The host presents products live on air. Your job is to help the show team decide
what to feature next based on stock levels and margins.

Given a list of SKUs with stock and margin data, respond ONLY with valid JSON:
{
  "push_next_sku": "SKU-001",
  "avoid_skus": ["SKU-003"],
  "alerts": [
    {"sku": "SKU-003", "alert_type": "critical", "units_remaining": 4,
     "recommendation": "Do not feature — only 4 units left, will stock-out in 8 min at current sell rate"}
  ],
  "host_tip": "Feature the Ruby Solitaire Gold Ring next — 36 units, highest margin tonight."
}

Rules:
- push_next: highest margin SKU with > 15 units remaining
- avoid: any SKU with < 6 units (critical stock-out risk)
- alert_type: "critical" < 6 units, "low" < 15 units, "stockout_imminent" selling > 3/min
- host_tip: one punchy sentence the floor manager can relay to the host
"""

    def advise(self, stock_items: list[StockItem]) -> InventoryAdvice:
        stock_data = json.dumps(
            [item.model_dump() for item in stock_items], indent=2
        )
        prompt = f"Current live show inventory:\n{stock_data}"
        result = self.call_llm_json(prompt, max_tokens=600)

        # Find the recommended item object
        push_sku = result["push_next_sku"]
        push_item = next((s for s in stock_items if s.sku == push_sku), stock_items[0])

        alerts = [
            InventoryAlert(
                sku=a["sku"],
                product_name=next((s.product_name for s in stock_items if s.sku == a["sku"]), a["sku"]),
                units_remaining=a["units_remaining"],
                alert_type=a["alert_type"],
                recommendation=a["recommendation"],
            )
            for a in result.get("alerts", [])
        ]

        return InventoryAdvice(
            push_next=push_item,
            avoid_now=result.get("avoid_skus", []),
            alerts=alerts,
            host_tip=result["host_tip"],
        )
