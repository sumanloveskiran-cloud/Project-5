from core.base_agent import BaseAgent
from core.models import Order, ReturnRiskResult, RiskLevel, InterventionAction


class ReturnPredictorAgent(BaseAgent):
    name = "return_predictor"
    system_prompt = """
You are a return risk scoring agent for Shop LC, an Indian home shopping TV channel.
Customers are mostly 50+ women who buy jewelry and gemstones.

Given an order, score its return probability 0-100 using these signals:
- First-time buyer: +30 points
- Order placed after 10 PM: +20 points
- Ring with size 5 or 6: +15 points (common sizing mistakes)
- Price above ₹3000: +10 points (hesitation on high spend)
- Category "ring": +10, "pendant": +5, "earring": +2
- Historical return rate > 20%: +25 points
- Historical return rate 10-20%: +10 points

Risk levels: 0-30 = low, 31-65 = medium, 66-100 = high
Actions: low → none, medium → sms, high → ivr_call

Respond ONLY with valid JSON, no markdown:
{
  "risk_score": 72,
  "risk_level": "high",
  "reasons": ["first-time buyer", "ordered at 11 PM", "size 5 ring"],
  "action": "ivr_call"
}
"""

    def score(self, order: Order) -> ReturnRiskResult:
        prompt = f"""
Order details:
- Order ID: {order.order_id}
- Product: {order.product_name}
- Category: {order.category}
- Price: ₹{order.price}
- Size: {order.size or 'N/A'}
- Order placed at: {order.order_hour}:00
- First order ever: {order.is_first_order}
- Customer's past return rate: {order.customer_return_rate * 100:.0f}%
"""
        result = self.call_llm_json(prompt)
        return ReturnRiskResult(
            order_id=order.order_id,
            risk_score=result["risk_score"],
            risk_level=RiskLevel(result["risk_level"]),
            reasons=result["reasons"],
            action=InterventionAction(result["action"]),
        )
