from core.base_agent import BaseAgent
from core.models import ReturnRiskResult, DailyInsight
from datetime import date
import json


class InsightAgent(BaseAgent):
    name = "insight_agent"
    system_prompt = """
You are a business insight agent for Shop LC, an Indian TV shopping channel.
At end of day, analyze all return risk scores and inventory data to find patterns.

Respond ONLY with valid JSON:
{
  "top_patterns": [
    "Size 5 rings have 3x higher return rate than other sizes",
    "Late-night orders (after 10 PM) return at 2x average rate",
    "First-time buyers account for 60% of high-risk orders"
  ],
  "recommendations": [
    "Host should verbally guide sizing during ring segments",
    "Add 24-hour confirmation call for first-time buyers over ₹3000",
    "Offer free size exchange to reduce ring returns"
  ]
}

Be specific, actionable, and data-driven. Max 4 patterns and 4 recommendations.
"""

    def generate(
        self,
        risk_results: list[ReturnRiskResult],
        total_orders: int,
        avg_order_value: float = 2200,
        avg_return_cost: float = 350,
    ) -> DailyInsight:
        high_risk = [r for r in risk_results if r.risk_score >= 66]
        medium_risk = [r for r in risk_results if 31 <= r.risk_score < 66]

        # Aggregate reason frequency
        reason_counts: dict[str, int] = {}
        for r in risk_results:
            for reason in r.reasons:
                reason_counts[reason] = reason_counts.get(reason, 0) + 1

        prompt = f"""
Today's summary:
- Total orders: {total_orders}
- High-risk orders (score ≥ 66): {len(high_risk)}
- Medium-risk orders (score 31-65): {len(medium_risk)}
- Top risk reasons and frequency: {json.dumps(reason_counts, indent=2)}
- Average order value: ₹{avg_order_value}
- Estimated return cost per order: ₹{avg_return_cost}

Find patterns and give actionable recommendations for the operations team.
"""
        result = self.call_llm_json(prompt, max_tokens=600)

        predicted_returns = len(high_risk) + len(medium_risk) // 2
        cost_saved = len(high_risk) * avg_return_cost * 0.6  # 60% intervention success

        return DailyInsight(
            date=str(date.today()),
            total_orders=total_orders,
            predicted_returns=predicted_returns,
            estimated_return_cost_saved=round(cost_saved, 2),
            top_patterns=result.get("top_patterns", []),
            recommendations=result.get("recommendations", []),
        )
